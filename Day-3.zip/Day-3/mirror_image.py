#mirror_image_of_a_string..

actual_image = input('Actual image :')
mirror_image = actual_image[ : :-1]
print('Mirror Image is :', mirror_image)
