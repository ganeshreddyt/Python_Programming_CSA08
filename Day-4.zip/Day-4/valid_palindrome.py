string_value =  input('Put a stirng here :')
s = ''.join(filter(str.isalpha, string_value))
s = s.lower()
if(s == s[::-1]):
    print(True)
else:
    print(False)
