Total=int(input("enter the total users :"))
staff=int(input("enter the staff users :"))

non_teaching = staff/3;

print('Student_users are :',int(Total-staff-non_teaching))
