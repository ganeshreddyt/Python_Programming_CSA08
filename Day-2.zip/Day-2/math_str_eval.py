#pgm to evalulate the given mathematcal expression

string = input("Enter mathematical string :")
ans = eval(string)

print("The ans. is :",ans)
