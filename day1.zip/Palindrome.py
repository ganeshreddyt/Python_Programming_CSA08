num=int(input())
g=str(num)
h=g[::-1]
k=int(h)
if num==k:
	print("True")
else:
	print("False")
