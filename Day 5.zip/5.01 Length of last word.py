s=input("Enter the string   :")
a=s.split()
b=len(a)
print("Length of the last word of the string",len(a[b-1]))
