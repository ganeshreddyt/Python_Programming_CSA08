s=input("Enter the string  :")
a=s.split()
a=list(reversed(a))
print("Reversed words in the string   :"," ".join(a))
